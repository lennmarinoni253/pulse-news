const state = {
  section: "today",
  club: "all",
  items: [],
  loading: false,
  saved: new Set(JSON.parse(localStorage.getItem("pulseSaved") || "[]")),
  read: new Set(JSON.parse(localStorage.getItem("pulseRead") || "[]"))
};

const sections = {
  today: { title: "Vandaag", eyebrow: "Jouw dagelijkse briefing" },
  sport: { title: "Sport", eyebrow: "Voetbal, wielrennen, tennis & meer" },
  clubs: { title: "Mijn clubs", eyebrow: "Alles over jouw vier ploegen" },
  world: { title: "Wereld", eyebrow: "Belangrijk nieuws buiten de lijnen" },
  tech: { title: "Tech", eyebrow: "Technologie, AI & innovatie" },
  saved: { title: "Opgeslagen", eyebrow: "Voor later bewaard" }
};

const $ = (q) => document.querySelector(q);
const $$ = (q) => [...document.querySelectorAll(q)];

function persist() {
  localStorage.setItem("pulseSaved", JSON.stringify([...state.saved]));
  localStorage.setItem("pulseRead", JSON.stringify([...state.read]));
}

function keyOf(item) {
  return item.id || item.link || item.title;
}

function stripHtml(input = "") {
  const doc = new DOMParser().parseFromString(input, "text/html");
  return (doc.body.textContent || "").replace(/\s+/g, " ").trim();
}

function relativeTime(dateString) {
  const d = new Date(dateString);
  if (Number.isNaN(d.getTime())) return "";
  const diff = Date.now() - d.getTime();
  const mins = Math.max(0, Math.floor(diff / 60000));
  if (mins < 1) return "net";
  if (mins < 60) return `${mins} min`;
  const h = Math.floor(mins / 60);
  if (h < 24) return `${h} u`;
  const days = Math.floor(h / 24);
  return `${days} d`;
}

function setStatus(text, online = false) {
  $("#statusText").textContent = text;
  $("#statusDot").classList.toggle("online", online);
}

function setActiveSection(section) {
  state.section = section;
  const cfg = sections[section];
  $("#pageTitle").textContent = cfg.title;
  $("#eyebrow").textContent = cfg.eyebrow;
  $$(".nav-item").forEach(b => b.classList.toggle("active", b.dataset.section === section));
  $("#clubTabs").classList.toggle("hidden", section !== "clubs");
  $("#hero").classList.toggle("hidden", section !== "today");
  $("#searchInput").value = "";
  loadNews();
}

async function loadNews(force = false) {
  if (state.loading) return;
  state.loading = true;
  setStatus("Nieuws laden…", false);
  $("#feedMeta").textContent = "Laatste nieuws wordt opgehaald…";

  try {
    if (state.section === "saved") {
      const all = JSON.parse(localStorage.getItem("pulseSavedItems") || "[]");
      state.items = all.filter(x => state.saved.has(keyOf(x)));
      render();
      setStatus("Lokaal opgeslagen", true);
      return;
    }

    const category = state.section === "clubs" ? state.club : state.section;
    const url = `/api/news?category=${encodeURIComponent(category)}${force ? `&t=${Date.now()}` : ""}`;
    const res = await fetch(url, { cache: force ? "no-store" : "default" });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const data = await res.json();
    state.items = Array.isArray(data.items) ? data.items : [];
    $("#feedMeta").textContent = `${state.items.length} berichten · bijgewerkt ${new Date().toLocaleTimeString("nl-BE", {hour:"2-digit", minute:"2-digit"})}`;
    setStatus("Live", true);
    render();
  } catch (err) {
    console.error(err);
    state.items = demoItems();
    $("#feedMeta").textContent = "Demo-weergave — publiceer Pulse om live nieuws te laden";
    setStatus("Demo", false);
    render();
  } finally {
    state.loading = false;
  }
}

function demoItems() {
  return [
    {
      id: "demo-1",
      title: "Pulse is klaar voor live nieuws",
      source: "Pulse",
      publishedAt: new Date().toISOString(),
      link: "https://news.google.com/",
      description: "Na publicatie haalt deze plek automatisch de nieuwste berichten op uit de ingestelde nieuwsfeeds."
    },
    {
      id: "demo-2",
      title: "Jouw clubnieuws krijgt een eigen overzicht",
      source: "Pulse",
      publishedAt: new Date(Date.now()-3600000).toISOString(),
      link: "https://news.google.com/",
      description: "KRC Genk, FC Barcelona, Newcastle United en Manchester City kunnen afzonderlijk worden gefilterd."
    },
    {
      id: "demo-3",
      title: "Bewaar artikels om ze later terug te vinden",
      source: "Pulse",
      publishedAt: new Date(Date.now()-7200000).toISOString(),
      link: "https://news.google.com/",
      description: "Favorieten en gelezen berichten worden op je toestel bewaard."
    }
  ];
}

function render() {
  const query = $("#searchInput").value.trim().toLowerCase();
  const filtered = state.items.filter(item => {
    const hay = `${item.title} ${item.source} ${stripHtml(item.description || "")}`.toLowerCase();
    return !query || hay.includes(query);
  });

  const grid = $("#newsGrid");
  grid.innerHTML = "";
  $("#emptyState").classList.toggle("hidden", filtered.length > 0);

  if (state.section === "today" && filtered[0]) {
    renderHero(filtered[0]);
  } else {
    $("#hero").classList.add("hidden");
  }

  const start = (state.section === "today" && filtered.length > 1) ? 1 : 0;
  filtered.slice(start).forEach(item => grid.appendChild(renderCard(item)));
}

function renderHero(item) {
  const hero = $("#hero");
  hero.classList.remove("hidden");
  hero.innerHTML = `
    <div class="hero-label">${escapeHtml(item.source || "Topverhaal")} · ${relativeTime(item.publishedAt)}</div>
    <h2>${escapeHtml(item.title)}</h2>
    <p>${escapeHtml(stripHtml(item.description || "").slice(0, 220) || "Open het artikel voor het volledige verhaal.")}</p>
    <a href="${safeUrl(item.link)}" target="_blank" rel="noopener noreferrer">Lees het topverhaal ↗</a>
  `;
}

function renderCard(item) {
  const tpl = $("#cardTemplate").content.cloneNode(true);
  const card = tpl.querySelector(".news-card");
  const key = keyOf(item);

  tpl.querySelector(".source").textContent = item.source || "Nieuws";
  tpl.querySelector(".time").textContent = relativeTime(item.publishedAt);
  tpl.querySelector(".headline").textContent = item.title;
  tpl.querySelector(".summary").textContent =
    stripHtml(item.description || "").slice(0, 260) || "Open het originele artikel voor meer informatie.";

  const link = tpl.querySelector(".read-link");
  link.href = safeUrl(item.link);
  link.addEventListener("click", () => {
    state.read.add(key);
    persist();
    card.classList.add("read");
  });

  card.classList.toggle("read", state.read.has(key));

  const save = tpl.querySelector(".save-button");
  const updateSave = () => {
    const active = state.saved.has(key);
    save.classList.toggle("saved", active);
    save.textContent = active ? "★" : "☆";
  };
  updateSave();

  save.addEventListener("click", () => {
    if (state.saved.has(key)) {
      state.saved.delete(key);
    } else {
      state.saved.add(key);
      const old = JSON.parse(localStorage.getItem("pulseSavedItems") || "[]");
      if (!old.some(x => keyOf(x) === key)) {
        old.unshift(item);
        localStorage.setItem("pulseSavedItems", JSON.stringify(old.slice(0, 200)));
      }
    }
    persist();
    updateSave();
    if (state.section === "saved") loadNews();
  });

  return tpl;
}

function escapeHtml(str = "") {
  return str.replace(/[&<>"']/g, ch => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[ch]));
}

function safeUrl(url = "") {
  try {
    const parsed = new URL(url);
    return /^https?:$/.test(parsed.protocol) ? parsed.href : "#";
  } catch {
    return "#";
  }
}

$$(".nav-item").forEach(btn => btn.addEventListener("click", () => setActiveSection(btn.dataset.section)));

$$(".club-tab").forEach(btn => btn.addEventListener("click", () => {
  state.club = btn.dataset.club;
  $$(".club-tab").forEach(x => x.classList.toggle("active", x === btn));
  loadNews(true);
}));

$("#searchInput").addEventListener("input", render);
$("#refreshBtn").addEventListener("click", () => loadNews(true));

$("#markAllRead").addEventListener("click", () => {
  state.items.forEach(item => state.read.add(keyOf(item)));
  persist();
  render();
});

$("#themeToggle").addEventListener("click", () => {
  const current = document.documentElement.dataset.theme;
  const next = current === "dark" ? "light" : "dark";
  document.documentElement.dataset.theme = next;
  localStorage.setItem("pulseTheme", next);
});

const savedTheme = localStorage.getItem("pulseTheme");
if (savedTheme) {
  document.documentElement.dataset.theme = savedTheme;
} else if (matchMedia("(prefers-color-scheme: dark)").matches) {
  document.documentElement.dataset.theme = "dark";
}

if ("serviceWorker" in navigator) {
  addEventListener("load", () => navigator.serviceWorker.register("/sw.js").catch(console.error));
}

loadNews();
