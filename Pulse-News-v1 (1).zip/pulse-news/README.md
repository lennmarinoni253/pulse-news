# Pulse

**Pulse — Alles wat vandaag telt.**

Een persoonlijke nieuwsreader als PWA, ontworpen voor iPad, pc en Mac.

## Wat werkt al

- Live nieuws via Google News RSS
- Vandaag, Sport, Wereld en Tech
- KRC Genk, FC Barcelona, Newcastle United en Manchester City
- Favorieten
- Gelezen/ongelezen
- Zoekfunctie
- Dark mode
- PWA / toevoegen aan iPad-beginscherm
- Offline app-shell
- Automatische deduplicatie van gelijkaardige headlines

## Snel publiceren op Vercel

1. Maak gratis een account op Vercel.
2. Upload deze projectmap naar GitHub of importeer ze in Vercel.
3. Vercel detecteert het project automatisch.
4. Klik **Deploy**.
5. Open de https-link op je iPad.
6. Safari → Deel → **Zet op beginscherm**.

## Lokaal testen

Installeer Node.js, open een terminal in deze map en voer uit:

```bash
npm install
npm run dev
```

Open daarna het lokale adres dat Vercel toont.

> Als je `index.html` rechtstreeks dubbelklikt, zie je de interface met demo-items.
> Live RSS-nieuws werkt via de serverless `/api/news`-functie en dus via Vercel Dev of een echte deployment.

## Nieuwsbronnen

De backend gebruikt Google News RSS-zoekfeeds om nieuws te verzamelen.
Pulse bewaart geen volledige artikels: het toont metadata/samenvattingen uit de feed en linkt door naar de originele bron.

## Volgende uitbreidingen

- Echte artikelafbeeldingen via Open Graph metadata
- Ochtend- en avondbriefing
- "Nieuw sinds 07:00"
- Slimmere ranking op basis van jouw interesses
- Pushmeldingen
- Bronfilters
- Aparte voetbalcompetities
- Automatische AI-samenvattingen
