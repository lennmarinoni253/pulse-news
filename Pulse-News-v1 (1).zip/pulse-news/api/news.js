const { XMLParser } = require("fast-xml-parser");
const crypto = require("crypto");

const parser = new XMLParser({
  ignoreAttributes: false,
  processEntities: true,
  trimValues: true
});

const locale = "&hl=nl&gl=BE&ceid=BE:nl";

const feeds = {
  today: [
    'België',
    'voetbal België',
    'technologie AI',
    '"KRC Genk" OR "FC Barcelona" OR "Newcastle United" OR "Manchester City"'
  ],
  sport: [
    'voetbal België OR Champions League',
    'wielrennen OR tennis sport'
  ],
  world: [
    'wereldnieuws Europa',
    'internationaal nieuws'
  ],
  tech: [
    'technologie AI Apple Microsoft Google'
  ],
  all: [
    '"KRC Genk" OR "FC Barcelona" OR "Newcastle United" OR "Manchester City"'
  ],
  genk: ['"KRC Genk" OR "Racing Genk"'],
  barcelona: ['"FC Barcelona" OR Barça'],
  newcastle: ['"Newcastle United"'],
  city: ['"Manchester City"']
};

function buildFeed(query) {
  return `https://news.google.com/rss/search?q=${encodeURIComponent(query)}${locale}`;
}

function asArray(value) {
  if (!value) return [];
  return Array.isArray(value) ? value : [value];
}

function stripHtml(value = "") {
  return String(value)
    .replace(/<script[\s\S]*?<\/script>/gi, " ")
    .replace(/<style[\s\S]*?<\/style>/gi, " ")
    .replace(/<[^>]*>/g, " ")
    .replace(/&nbsp;/g, " ")
    .replace(/&amp;/g, "&")
    .replace(/&quot;/g, '"')
    .replace(/&#39;/g, "'")
    .replace(/\s+/g, " ")
    .trim();
}

function parseSource(item, title) {
  const source = typeof item.source === "object" ? item.source["#text"] : item.source;
  if (source) return String(source).trim();

  const match = String(title || "").match(/\s+-\s+([^-]+)$/);
  return match ? match[1].trim() : "Nieuws";
}

function cleanTitle(title, source) {
  const suffix = ` - ${source}`;
  return String(title || "").endsWith(suffix)
    ? String(title).slice(0, -suffix.length).trim()
    : String(title || "").trim();
}

function idFor(item) {
  return crypto
    .createHash("sha1")
    .update(`${item.link || ""}|${item.title || ""}`)
    .digest("hex")
    .slice(0, 16);
}

async function fetchFeed(query) {
  const response = await fetch(buildFeed(query), {
    headers: {
      "User-Agent": "Pulse-News/1.0 (+personal news reader)",
      "Accept": "application/rss+xml, application/xml, text/xml"
    }
  });

  if (!response.ok) throw new Error(`RSS ${response.status}`);

  const xml = await response.text();
  const data = parser.parse(xml);
  const items = asArray(data?.rss?.channel?.item);

  return items.map(item => {
    const source = parseSource(item, item.title);
    return {
      id: idFor(item),
      title: cleanTitle(item.title, source),
      source,
      publishedAt: item.pubDate || new Date().toISOString(),
      link: item.link || "#",
      description: stripHtml(item.description || "")
    };
  });
}

module.exports = async function handler(req, res) {
  const category = String(req.query.category || "today").toLowerCase();
  const queries = feeds[category] || feeds.today;

  try {
    const settled = await Promise.allSettled(queries.map(fetchFeed));
    const all = settled
      .filter(x => x.status === "fulfilled")
      .flatMap(x => x.value);

    const seen = new Set();
    const unique = all.filter(item => {
      const normalized = item.title.toLowerCase().replace(/[^\p{L}\p{N}]+/gu, " ").trim();
      const key = normalized.slice(0, 100);
      if (seen.has(key)) return false;
      seen.add(key);
      return true;
    });

    unique.sort((a, b) => new Date(b.publishedAt) - new Date(a.publishedAt));

    res.setHeader("Cache-Control", "s-maxage=300, stale-while-revalidate=900");
    res.status(200).json({
      category,
      updatedAt: new Date().toISOString(),
      items: unique.slice(0, 60)
    });
  } catch (error) {
    res.status(500).json({ error: "Nieuws kon niet worden opgehaald.", detail: error.message });
  }
};
